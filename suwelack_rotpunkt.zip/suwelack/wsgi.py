#!C:/PKS_Apache_Version/suwelack/pks_env/Scripts

import sys
sys.path.append("C:\\PKS_Apache_Version\\suwelack")

from app import app

application = app
