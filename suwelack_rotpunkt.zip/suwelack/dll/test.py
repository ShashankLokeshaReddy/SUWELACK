﻿scanvalue="1024"
result=""    
appmscreen2=1
print (scanvalue ,'gg',result,appmscreen2)